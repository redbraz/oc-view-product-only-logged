<?php
// Heading
$_['heading_title']    = 'Product View Restriction';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Product View Restriction module!';
$_['text_edit']        = 'Edit Product View Restriction Module';
$_['text_enabled']        = 'Yes';
$_['text_disabled']        = 'No';


// Entry
$_['entry_status']     = 'Status';
$_['entry_cat_status']     = 'Restrict Category View';
$_['entry_pro_status']     = 'Restrict Product View';




// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Product View Restriction module!';